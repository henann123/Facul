package questao6kyu;

import java.util.Scanner;

public class Somadosd�gitos {

	public static void main(String[] args) {
		
		    
			
			
			System.out.println("Digite um n�mero: ");
	        int num = new Scanner(System.in).nextInt();
	        int soma = somaAlg(num);
	        System.out.println("A soma dos algarismos �: " + soma);
	        }
		
		   
		     
		
	public static int somaAlg(int n) {
	 if(n<10){
		    return n;
		    }else{
		       return somaAlg(n/10)+n%10;
		   }
		    
		  }
}
